export const environment = {
  production: true,
  apiBaseUrl: '/api', // Replace with actual production API URL
};
