import { Component } from '@angular/core';

@Component({
  selector: 'app-presons-details',
  imports: [],
  templateUrl: './presons-details.component.html',
  styleUrl: './presons-details.component.scss'
})
export class PresonsDetailsComponent {

}
