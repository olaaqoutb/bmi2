import { Component } from '@angular/core';

@Component({
  selector: 'app-nachverrechnung-details',
  imports: [],
  templateUrl: './nachverrechnung-details.component.html',
  styleUrl: './nachverrechnung-details.component.scss'
})
export class NachverrechnungDetailsComponent {

}
