import { Component } from '@angular/core';

@Component({
  selector: 'app-organisationseinheit-detail',
  imports: [],
  templateUrl: './organisationseinheit-detail.component.html',
  styleUrl: './organisationseinheit-detail.component.scss'
})
export class OrganisationseinheitDetailComponent {

}
