import { Component } from '@angular/core';

@Component({
  selector: 'app-taetigkeiten-historisch-detail',
  imports: [],
  templateUrl: './taetigkeiten-historisch-detail.component.html',
  styleUrl: './taetigkeiten-historisch-detail.component.scss'
})
export class TaetigkeitenHistorischDetailComponent {

}
