import { Component } from '@angular/core';

@Component({
  selector: 'app-taetigkeiten-korrigieren-detail',
  imports: [],
  templateUrl: './taetigkeiten-korrigieren-detail.component.html',
  styleUrl: './taetigkeiten-korrigieren-detail.component.scss'
})
export class TaetigkeitenKorrigierenDetailComponent {

}
