import { Component } from '@angular/core';

@Component({
  selector: 'app-stempelzeit-details',
  imports: [],
  templateUrl: './stempelzeit-details.component.html',
  styleUrl: './stempelzeit-details.component.scss'
})
export class StempelzeitDetailsComponent {

}
