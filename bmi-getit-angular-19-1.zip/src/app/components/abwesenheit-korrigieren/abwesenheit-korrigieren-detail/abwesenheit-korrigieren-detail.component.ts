import { Component } from '@angular/core';

@Component({
  selector: 'app-abwesenheit-korrigieren-detail',
  imports: [],
  templateUrl: './abwesenheit-korrigieren-detail.component.html',
  styleUrl: './abwesenheit-korrigieren-detail.component.scss'
})
export class AbwesenheitKorrigierenDetailComponent {

}
