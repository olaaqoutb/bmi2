import { Component } from '@angular/core';

@Component({
  selector: 'app-bereitschaft-korrigieren-details',
  imports: [],
  templateUrl: './bereitschaft-korrigieren-details.component.html',
  styleUrl: './bereitschaft-korrigieren-details.component.scss'
})
export class BereitschaftKorrigierenDetailsComponent {

}
