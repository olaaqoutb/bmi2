export interface PersonTEst2 {
}
